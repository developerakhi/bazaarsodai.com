		 
        <div class="static-content-wrapper">
              <div class="static-content">
                   <div class="page-content">
                       <ol class="breadcrumb">
							<li class=""><a href="index.php">Home</a></li>
							<li class="active"><a href="index.php">Dashboard</a></li>
							</ol>
							<div class="page-heading">            
                               <h1>Dashboard</h1>
							</div>

							
<div class="container-fluid">
<div data-widget-group="group1">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="info-tile info-tile-alt tile-indigo">
                <div class="info">
                    <div class="tile-heading"><span>Page Views</span></div>
                    <div class="tile-body"><span>5,921</span></div>
                </div>
                <div class="stats">
                    <div class="tile-content"><div id="dashboard-sparkline-indigo"></div></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="info-tile info-tile-alt tile-danger">
                <div class="info">
                    <div class="tile-heading"><span>Aquisitions</span></div>
                    <div class="tile-body "><span>2,344</span></div>
                </div>
                <div class="stats">
                    <div class="tile-content"><div id="dashboard-sparkline-gray"></div></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="info-tile info-tile-alt tile-primary">
                <div class="info">
                    <div class="tile-heading"><span>Conversions</span></div>
                    <div class="tile-body "><span>1,032</span></div>
                </div>
                <div class="stats">
                    <div class="tile-content"><div id="dashboard-sparkline-primary"></div></div>
                </div>
            </div>
        </div>
		
    </div>


                     </div> <!-- .container-fluid -->
                 </div> <!-- #page-content -->
              </div>
					