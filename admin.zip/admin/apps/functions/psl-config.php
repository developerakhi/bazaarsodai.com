<?php 
 define("HOST", "localhost");     // The host you want to connect to.
define("USER", "bazaarsodai_mrk14837");    // The database username. 
define("PASSWORD", "j+AV$~=pL2x)");    // The database password. 
define("DATABASE", "bazaarsodai_mrk14837");    // The database name.
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", FALSE);    // FOR DEVELOPMENT ONLY!!!!

 ?>