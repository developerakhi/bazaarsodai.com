function studentDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_student.php";
document.frmUser.submit();
}
}

function DataDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_database.php";
document.frmUser.submit();
}
}



function personeDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_persone.php";
document.frmUser.submit();
}
}


function videoDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_video.php";
document.frmUser.submit();
}
}


function fileDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_file.php";
document.frmUser.submit();
}
}


function booksDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_books.php";
document.frmUser.submit();
}
}



function workshopDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_events.php";
document.frmUser.submit();
}
}

function imageDeleteAction() {
if(confirm("Are you sure want to delete these rows?")) {
document.frmUser.action = "delete_image.php";
document.frmUser.submit();
}
}
